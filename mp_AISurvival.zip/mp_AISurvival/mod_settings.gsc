init()
{
	//credits
    //Cyborgking for creating the mod
    //Makers of itszombiemod for some code bits.
    //Jorankille for testing the mod
    //XG R4PiDzZ and Zy0n- for the shop menu in version 0.1 and 0.2
    //Se7en for the points gain effect
    //Azumikkel for the key binding in version 0.1 and 0.2
    //Nukem for the unused key tip, explaining me about the overflow error and some bits of code
    //zxz0O0 for the base code of the fire effect and damage over time of the dragons breath
	//master101 for providing the round float function
    //ieagle for the easy menu example
    //Everybody who has made awesome tutorials!
	//Thanks to all clans, communities and individuals who have given their support through donations, hosting and other ways.
 
 
    //general settings
	level.modprematch = 0; 			// sets the gamemodes own prematch countdown in seconds: 0= start instantly  (default= 0)
    level.round_interval = 20; 			// sets how much time there is between two rounds:  (default= 20)
	level.botamount = 1.0; 				// sets how much more bots you have to kill by default: 1.0= no change, 1.1= 10% more bots by default  (default= 1.0)
	level.explosivedamage = .4; 		// sets how much damage is done to a player with explosives: .4= 40% of the normal explosive damage  (default= .4)
    level.aicorestrictsmoke = 1; 		// sets what will replace a willy pete: 0=no replacing, 1= nova gas, 2= conccusion, 3= flashbang  (default= 1)
	level.easymode = false; 			// sets easy mode, players respawn instantly and the game will only end when all rounds are completed:  (default= false)
    
	//map vote settings
	level.mapvote = true;				// sets whether players vote for the next map at the end of the game: true= vote, false= normal map rotation  (default= true)
	level.mapvote_time = 30;			// sets how long the vote lasts in seconds, it ends early once everyone has voted: 0= until everyone has voted  (default= 30)

	//hud settings
	level.killmarkerreq = 5; 			// sets how much bots have to be left before the kill markers will show: 0= never show killmarkers, -1= always show killmarkers  (default= 5)
	level.hpbar	= true;					// sets whether the health bar should be shown: true= show, false= hidden  (default= true)
	level.revbar = true;				// sets whether the revive progress ar should be shown: true= show, false= hidden  (default= true)
	level.hchud = false;				// sets what hud type the game should use: false= normal hud, true= hardcore hud  (default= false)
	
    //bot settings
    level.num_enemies = 18; 			// sets the number of enemy bots that can be alive at once, capped at sv_maxclients - 4 (4 slots kept for survivors): (default= 10)
    level.botsdifficulty = "normal"; 	// sets the difficulty: easy, normal, normal-hard, hard, fu  (default= normal)
	level.ainame = false;				// sets whether the red name above bots should be shown: true= shown, false= hidden  (default= false)
    level.aimeleedamage = 50; 			// sets how much damage a bot does with melee:  (default= 50)
    level.botbulletdamage = .1; 		// sets how much damage a bot does with bullets: .1= 10% of the normal bullet damage  (default= .1) 
    
    //dog settings
    level.num_dogs = 4; 				// sets the number of dogs that can be alive at once on the AI team in round 5:  (default= 4)
    level.dogrespawntime = 3.5; 		// sets how much time there is between two dogs respawning on the AI team in round 5:  (default= 3.5)
    level.doghurtdamage = 1.5; 			// sets how much more damage a player does with bullets to a dog on the AI team in round 5: 1.5= 50% more damage with bullets  (default= 1.5)
    level.aidogdamage = 25; 			// sets how much damage a bite of a dog on the AI team does:  (default= 25)
    
    //score settings
    level.killscore = 150;	 			// sets how much points and credits you get for a kill:  (default= 150)
    level.meleekillscore = 250; 		// sets how much points and credits you get for a melee kill:  (default= 250)
    level.headshotkillscore = 250; 		// sets how much points and credits you get for a headshot kill:  (default= 250)
    level.dogkillscore = 50; 			// sets how much points and credits you get for a dog kill:  (default= 50)
    level.assist1score = 40; 			// sets how much points and credits you get for a first level assist:  (default= 40)
    level.assist2score = 80; 			// sets how much points and credits you get for a second level assist:  (default= 80)
    level.assist3score = 120; 			// sets how much points and credits you get for a third level assist:  (default= 120)
    level.assist4score = 160; 			// sets how much points and credits you get for a fourth level assist:  (default= 160)
    level.doublekillscore = 100; 		// sets how much points and credits you get for a double kill:  (default= 100)
    level.triplekillscore = 150; 		// sets how much points and credits you get for a triple kill:  (default= 150)
    level.multikillscore = 200; 		// sets how much points and credits you get for a multi kill:  (default= 150)
    level.deadpenalty = 150; 			// sets how much points you lose when you die:  (default= 150)

    //multipliers settings
    //multipliers are here to keep the game balanced with multiple players
    //all the multipliers totals, except the earnings multiplier, are set at the start of a new round and are based on the amount of players that are alive when the round starts.
	//an example for level.botbulletdamagemult: 3 players at round start, level.botbulletdamagemult= .15, so multiplier total= .3, bot bullet damage will be 30% more than the base value(base value= damage*level.botbulletdamage)
    level.botbulletdamagemult = .15; 	// sets how much damage the bots do more with bullets per additional player: .15= 15% more per additional player  (default= .15)
    level.botbulletdamagemult_max = -1; // sets the maximum of the above multipliers total: -1= unlimited  (default= -1)
	level.explosivedamagemult = 0; 		// sets how much damage explosives do more to player per additional player: .15
	level.explosivedamagemult_max = -1; // sets the maximum of the above multipliers total, -1= unlimited  (default= -1) 
    level.botamountmult = .2; 			// sets how much more bots you have to kill each round per additional player: default is .15
    level.botamountmult_max = -1; 		// sets the maximum of the above multipliers total, -1= unlimited  (default= -1)
    level.num_dogsmult = .25; 			// sets how much more dogs there can be alive on the AI side at once in round 5 per additional player: default is .5
    level.num_dogsmult_max = -1; 		// sets the maximum of the above multipliers total, -1= unlimited  (default= -1)
	level.dogrespawntimemult = .02; 	// sets how much faster the dogs respawn on the AI side in round 5 per additional player: default is .02
    level.dogrespawntimemult_max = .5; 	// sets the maximum of the above multipliers total, -1= unlimited, (default= .5)
    level.moneymult = 0.03; 			// sets how much more money the players get per additional player alive on the survivors team: dfefault is 0.03
    level.moneymult_max = -1; 			// sets the maximum of the above multipliers total, -1= unlimited  (default= -1)
	
	//glitchy areas settings
    //Glitchy areas are areas where the bots have a very hard time trying or are unable to hit you.
    level.block_summit = true; 			// blocks a glitchy area on summit(the railing in the center building): false= don't block, true= block  (default= true)
    level.block_firingrange = true; 	// blocks a glitchy area on firing range(the car near the container tunnel): false= don't block, true= block  (default= true) 

	//survival settings (MW3 Spec Ops Survival style)
	level.maxwaves = 40;						// sets after which wave the team wins (the last wave is the final boss: gunship + juggernauts): 0= endless  (default= 40)
	level.start_pistol = "m1911_mp";		// sets the pistol every survivor spawns with  (default= "m1911_mp")
	level.start_perk = "specialty_movefaster";	// sets the one perk every survivor spawns with, "" for none  (default= "specialty_movefaster", Lightweight)
	level.start_frags = 1;					// sets the frag grenades every survivor spawns with  (default= 1)
	level.wavebonus = 500;					// sets the cash every living survivor gets for surviving a wave  (default= 500)
	level.wavebonus_perwave = 100;			// sets the extra wave bonus per wave number  (default= 100)
	level.dogwave_every = 5;				// sets how often attack dogs join a wave, counted from level.dogwave_first: 5= every 5th wave (3, 8, 13 ...), 0= never  (default= 5)
	level.jugg_firstwave = 8;				// sets the first wave with juggernauts  (default= 8)
	level.jugg_health = 600;				// sets the juggernaut health, +25 per wave  (default= 600)
	level.jugg_closedamage = 2.0;			// sets how much more damage a juggernaut does within 400 units  (default= 2.0)
	level.jugg_round_wave = 12;				// sets the first juggernaut-only round, 0= none  (default= 12)
	level.jugg_round_every = 10;			// sets a repeat of the juggernaut round every N waves after it  (default= 10)
	level.jugg_round_count = 6;				// sets the juggernauts in the first juggernaut round, +1 each one after  (default= 6)
	level.jugg_round_health_scale = 4;		// sets their health, times a normal juggernaut's  (default= 4)
	level.start_health = 200;				// sets the survivors' health at spawn  (default= 200, stock 100)
	level.ai_grenades_wave = 2;				// sets the first wave with grenadier AI (never Tomahawks)  (default= 2)
	level.ai_grenadier_chance = 0.15;		// sets the share of the AI that spawn as grenadiers, the rest carry no grenades  (default= 0.15)
	level.ai_grenadier_refill = 20;			// sets the seconds until a grenadier gets another grenade  (default= 20)
	level.heli_boss_wave = 5;				// sets the boss wave: enemy attack helicopters only, no infantry, 0= no boss wave  (default= 5)
	level.heli_boss_every = 0;				// sets a repeat of the boss wave every N waves after it, 0= only once  (default= 0)
	level.heli_boss_count = 2;				// sets how many helicopters a boss wave has  (default= 2)
	level.heli_boss_reward = 1000;			// sets the cash for shooting a boss helicopter down  (default= 1000)
	level.heli_boss_damage = 0.5;			// sets the boss helicopters' cannon damage to survivors, 1= stock  (default= 0.5)
	level.gunship_boss_wave = 15;			// sets the later boss wave: one gunship on its own, 0= none  (default= 15)
	level.gunship_boss_every = 10;			// sets a repeat of the gunship wave every N waves after it, 0= only once  (default= 10)
	level.gunship_health_scale = 3;			// sets the gunship's health, times an armoured attack helicopter's  (default= 3)
	level.gunship_boss_damage = 0.8;		// sets the gunship's cannon damage to survivors, 1= stock  (default= 0.8)
	level.gunship_boss_reward = 4000;		// sets the cash for shooting the gunship down  (default= 4000)
	level.heli_round_wave = 10;				// sets the first helicopter round: two attack helicopters, no infantry, 0= none  (default= 10)
	level.heli_round_every = 10;			// sets a repeat of the helicopter round every N waves after it  (default= 10)
	level.smg_damage_buff = 1.2;			// sets the survivors' SMG damage to the AI, every SMG, 1= stock  (default= 1.2)
	level.thundergun_range = 1200;			// sets how far the Thundergun blast reaches  (default= 1200)
	level.thundergun_fling_range = 480;		// sets the range inside which the Thundergun kills and throws  (default= 480)
	level.thundergun_gib_damage = 300;		// sets the Thundergun damage at mid range (480-900)  (default= 300)
	level.ai_hunt = true;					// sets whether AI with nothing to shoot head for the nearest survivor  (default= true)
	level.ai_far_distance = 2500;			// sets how far from every survivor an AI counts as too far  (default= 2500)
	level.ai_far_time = 8;					// sets the seconds an AI may stay too far before it's moved closer, out of sight, 0= never  (default= 8)
	level.ai_stuck_time = 10;				// sets the seconds an AI may stand still (64 units) with nothing to shoot before it's moved, 0= never  (default= 10)
	level.difficulty_ramp = true;			// sets whether the bots get harder every 6 waves, starting at level.botsdifficulty  (default= true)
	level.bothealth_perwave = 3;			// sets the extra bot health per wave  (default= 3)
	level.ai_body = "standard_mp";			// sets the enemy body: standard_mp, utility_mp, hardened_mp, ordnance_disposal_mp  (default= "standard_mp")
	level.ghillie_chance = 0;				// sets the chance of a ghillie suit enemy WITHOUT a sniper rifle (AI snipers always wear one): 0.1= 10%  (default= 0)
	level.dogwave_first = 3;				// sets the first wave attack dogs join, then every level.dogwave_every waves  (default= 3)
	level.final_gunship_health_scale = 5;	// sets the final wave gunship health (last wave, level.maxwaves), times an armoured attack helicopter's  (default= 5)
	level.final_jugg_count = 4;				// sets how many juggernauts come with the final wave gunship  (default= 4)
	level.final_jugg_health_scale = 6;		// sets their health, times a normal juggernaut's  (default= 6)
	level.napalm_first_wave = 4;			// sets the first wave with enemy napalm strikes (infantry waves only), 0= never  (default= 4)
	level.napalm_interval_min = 45;			// sets the shortest time between two napalm strikes in seconds  (default= 45)
	level.napalm_interval_max = 75;			// sets the longest time between two napalm strikes in seconds  (default= 75)
	level.napalm_damage = 0.5;				// sets the napalm damage to survivors, 1= stock  (default= 0.5)
	level.laststand_time = 60;				// sets how many seconds a downed survivor lasts before bleeding out, they can't be hurt while down  (default= 60)
}
